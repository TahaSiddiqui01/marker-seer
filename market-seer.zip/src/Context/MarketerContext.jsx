import { createContext } from "react";

const MarketerContext = createContext("");

export default MarketerContext;