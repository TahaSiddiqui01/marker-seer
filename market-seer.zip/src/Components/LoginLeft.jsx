import React from "react";
import "./LoginLeft.css";

function LoginLeft() {
  return (
    <>
      <div className="w-2/4 login-image  h-screen">
        <p className="text-white heading-text text-[30px] mx-16 py-24">
          Market Seer
        </p>
      </div>
    </>
  );
}

export default LoginLeft;
